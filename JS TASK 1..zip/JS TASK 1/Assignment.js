// //6 question

// function VowelCount(string) {
//     // Using a regular expression to match all vowels (both lowercase and uppercase)
   
//     let vowels= /[aeiouAEIOU]/g;
//     //this line to watch out the vowels 
//     //let vowels = /[aeiou]/gi;
//     //this line will search the string with containing vowels
//     let vowelsArray = string.match(vowels);
//     //ternary operator 
//     return vowelsArray ? vowelsArray.length : 0;
// }
// const inputString = "AaIi";
// const vowelCount = VowelCount(inputString);
// console.log(vowelCount);

//7th question 

// function find_Min_Max(numbers) {
//     if (numbers.length === 0) {
//       return { 
//         MaximumNumber: "undefined", 
//         MinimumNumber: "undefined" 
//     };
//     }
  
//     let max = Math.max(...numbers);
//     let min = Math.min(...numbers);
  
//     return { max, min };
//   }
  

//   const numbers = [123,3455,678,345];
//   const result = find_Min_Max(numbers);
//   console.log(result); 
  

//   let a = [1,2,3]
//   let b = [3,5,6]
//   let res = [...a,...b]
//   console.log(res)


//   function findMaxAndMin(numbers) {
//   const max = numbers.length === 0 ? undefined : numbers.reduce((acc, num) => Math.max(acc, num));
//   const min = numbers.length === 0 ? undefined : numbers.reduce((acc, num) => Math.min(acc, num));

//   return {resultmsg:`The Maximum number in the list is ${max},The Minimum number in the list is ${min}`};
// }


// const numbersArray = [2,6,8,2];
// const result = findMaxAndMin(numbersArray);
// console.log(result.resultmsg); 



// //2nd question
// console.log(5>4)
// console.log("2" > "12")
// console.log("apple" > "pineapple")
// console.log("apple" > "apple")

// console.log(undefined == null);
// console.log(undefined === null);
// console.log(null == "\n\n")
// console.log(null === + +"\n\n")

// //3rd question

// let a = 2 
// let x = 1 + (a*= 2)
// console.log(a)
// console.log(x)